import socket
import select
import sys
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives.hashes import SHA256
from cryptography.hazmat.primitives import serialization
import os
from cryptography.hazmat.primitives.ciphers import Cipher
from cryptography.hazmat.primitives.ciphers.algorithms import AES
from cryptography.hazmat.primitives.ciphers.modes import GCM
from .util import flatten_parameters_to_bytestring
import base64
from Crypto.Cipher import AES

""" @author: Aron Nieminen, Mojang AB"""

class RequestError(Exception):
    pass

class Connection:
    """Connection to a Minecraft Pi game"""
    RequestFailed = "Fail"
    pkcs_padding = padding.PKCS1v15()
    
    def __init__(self, address, port):
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.connect((address, port))
        self.server_public_key, self.private_key = self.rsa_key_exchange()
        self.gcm_info = self.send_gcm_info()
        self.lastSent = ""

    def rsa_key_exchange(self):
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048
        )
        public_key = private_key.public_key()
        pem_public = public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
        serialized_server_public_key = self.socket.recv(2048)
        serialized_server_public_key = serialized_server_public_key[:-1]
        serialized_server_public_key = base64.b64decode(serialized_server_public_key)
        server_public_key = serialization.load_pem_public_key(
            serialized_server_public_key
        )
        pem_public = base64.b64encode(pem_public.decode().encode('utf-8'))
        self.socket.send(pem_public)
        self.socket.send("\n".encode())
        return server_public_key, private_key
        
    def send_gcm_info(self):
        key = os.urandom(256 // 8)
        iv = os.urandom(96 // 8)
        associated_data = b'password'
        key_en = self.server_public_key.encrypt(key, self.pkcs_padding)
        key_wrap = base64.b64encode(key_en)
        self.socket.send(key_wrap)
        self.socket.send('\n'.encode())
        iv_en = self.server_public_key.encrypt(iv, self.pkcs_padding)
        iv_wrap = base64.b64encode(iv_en)
        self.socket.send(iv_wrap)
        self.socket.send('\n'.encode())
        associated_data = self.server_public_key.encrypt(associated_data, self.pkcs_padding)
        associated_data_wrap = base64.b64encode(associated_data)
        self.socket.send(associated_data_wrap)
        self.socket.send('\n'.encode())
        return key, iv, b'password'
        

    def drain(self):
        """Drains the socket of incoming data"""
        while True:
            readable, _, _ = select.select([self.socket], [], [], 0.0)
            if not readable:
                break
            data = self.socket.recv(1500)
            e =  "Drained Data: <%s>\n"%data.strip()
            e += "Last Message: <%s>\n"%self.lastSent.strip()
            sys.stderr.write(e)

    def send(self, f, *data):
        """
        Sends data. Note that a trailing newline '\n' is added here

        The protocol uses CP437 encoding - https://en.wikipedia.org/wiki/Code_page_437
        which is mildly distressing as it can't encode all of Unicode.
        """

        s = b"".join([f, b"(", flatten_parameters_to_bytestring(data), b")"])
        cipher = AES.new(self.gcm_info[0], AES.MODE_GCM, nonce=self.gcm_info[1], mac_len=16)
        cipher.update(self.gcm_info[2])
        ciphertext, tag = cipher.encrypt_and_digest(s)
        s = ciphertext + tag
        s = base64.b64encode(s)
        print(s)
        s = s + b'\n'
        self._send(s)
        

    def _send(self, s):
        """
        The actual socket interaction from self.send, extracted for easier mocking
        and testing
        """
        self.drain()
        self.lastSent = s
        self.socket.sendall(s)

    def receive(self):
        """Receives data. Note that the trailing newline '\n' is trimmed"""
        s = self.socket.makefile("r").readline().rstrip("\n")
        if s == Connection.RequestFailed:
            raise RequestError("%s failed"%self.lastSent.strip())
        return s

    def sendReceive(self, *data):
        """Sends and receive data"""
        self.send(*data)
        return self.receive()
    
    def gcm_encrypt(self, msg):
        key, iv, associated_data = self.gcm_info
        aes_gcm_encryptor = Cipher(AES(key), GCM(iv)).encryptor()
        aes_gcm_encryptor.authenticate_additional_data(associated_data)
        message = aes_gcm_encryptor.update(msg) + aes_gcm_encryptor.finalize()
        auth_tag = aes_gcm_encryptor.tag
        return message, auth_tag
